/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package event_management;

//import com.mysql.cj.xdevapi.Statement;
//import com.sun.jdi.connect.spi.Connection;
import com.mysql.cj.jdbc.result.ResultSetMetaData;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.sql.ResultSet;






/**
 *
 * @author ragul
 */
public class view_table extends javax.swing.JFrame {

    private static Connection Connection(String jdbcmysqllocalhost3306eventmng, String root, String ragul2406) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
    
    
    public view_table() {
        initComponents();
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        tab = new javax.swing.JTable();
        jLabel1 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        jLabel2 = new javax.swing.JLabel();
        ven_field = new javax.swing.JTextField();
        jButton2 = new javax.swing.JButton();
        jLabel3 = new javax.swing.JLabel();
        name_field2 = new javax.swing.JTextField();
        jScrollPane2 = new javax.swing.JScrollPane();
        table2 = new javax.swing.JTable();
        jLabel4 = new javax.swing.JLabel();
        jButton3 = new javax.swing.JButton();
        jLabel5 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setPreferredSize(new java.awt.Dimension(1500, 1000));
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        tab.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        tab.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tabAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
            }
        });
        jScrollPane1.setViewportView(tab);

        getContentPane().add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 120, 660, 300));

        jLabel1.setFont(new java.awt.Font("Footlight MT Light", 1, 36)); // NOI18N
        jLabel1.setText("DISPLAY VENUES");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(200, 20, -1, -1));

        jButton1.setFont(new java.awt.Font("Cambria Math", 0, 18)); // NOI18N
        jButton1.setText("VIEW AVAILABLE VENUES");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(230, 70, -1, 20));

        jLabel2.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel2.setText("SELECTED VENUE ID");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 210, -1, 20));

        ven_field.setPreferredSize(new java.awt.Dimension(100, 30));
        ven_field.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                ven_fieldActionPerformed(evt);
            }
        });
        getContentPane().add(ven_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 200, -1, -1));

        jButton2.setFont(new java.awt.Font("Cambria Math", 1, 14)); // NOI18N
        jButton2.setText("SUBMIT");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton2ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton2, new org.netbeans.lib.awtextra.AbsoluteConstraints(870, 310, -1, -1));

        jLabel3.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel3.setText("SELECTED VENUE NAME");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(710, 260, -1, -1));

        name_field2.setPreferredSize(new java.awt.Dimension(150, 25));
        getContentPane().add(name_field2, new org.netbeans.lib.awtextra.AbsoluteConstraints(930, 250, -1, -1));

        table2.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {

            },
            new String [] {

            }
        ));
        jScrollPane2.setViewportView(table2);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(20, 490, 660, 140));

        jLabel4.setFont(new java.awt.Font("Footlight MT Light", 1, 36)); // NOI18N
        jLabel4.setText("SCHEDULED EVENTS");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(210, 440, -1, -1));

        jButton3.setFont(new java.awt.Font("Cambria Math", 0, 14)); // NOI18N
        jButton3.setText("ACCESS ADDITIONAL FACILITIES");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton3ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton3, new org.netbeans.lib.awtextra.AbsoluteConstraints(800, 380, -1, -1));

        jLabel5.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img11.jpg"))); // NOI18N
        jLabel5.setPreferredSize(new java.awt.Dimension(1500, 1000));
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, -140, 1170, 1000));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tabAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tabAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tabAncestorAdded

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        // TODO add your handling code here:
        
        try 
        {
            Input_details privateObject = new Input_details();
            String val = privateObject.getpv();
            System.out.println(val);
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406");
            Statement st = con.createStatement();
            String query = "SELECT * FROM venues " + "WHERE venue_id IN (SELECT venue_id FROM venues WHERE availability = 'available' AND venue_location = '" + val + "')";
            ResultSet rs = st.executeQuery(query);
    
            // Create a DefaultTableModel
            DefaultTableModel model = new DefaultTableModel();

            // Get the metadata of the result set
            java.sql.ResultSetMetaData rsmd = rs.getMetaData();
            int cols = rsmd.getColumnCount();

            // Add column names to the model
            for (int i = 1; i <= cols; i++) {
                model.addColumn(rsmd.getColumnName(i));
            }

            // Add data to the model
            while (rs.next()) 
            {
                Object[] row = new Object[cols];
                for (int i = 1; i <= cols; i++) 
                {
                    row[i - 1] = rs.getObject(i);
                }
                model.addRow(row);
            }

            // Set the model to your JTable 'tab'
            tab.setModel(model);

            con.close(); // Don't forget to close the connection when done
        } 
        catch (SQLException ex) {
        Logger.getLogger(view_table.class.getName()).log(Level.SEVERE, null, ex);
        }
        catch (ClassNotFoundException ex) 
        {
            Logger.getLogger(view_table.class.getName()).log(Level.SEVERE, null, ex);
        }   
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void ven_fieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_ven_fieldActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_ven_fieldActionPerformed

    private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton2ActionPerformed
        try 
        {
            // TODO add your handling code here:
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con1 = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406");
            Input_details privateObject1 = new Input_details();
            int event_id = privateObject1.getPrivateVariable();
            String venue_id = ven_field.getText();
            String ven_name = name_field2.getText();
            int fin_venid = Integer.parseInt(venue_id);
            
            String updateQuery = "UPDATE SCHEDULED_EVENTS SET VENUE_ID = ?, VENUE_NAME = ? WHERE EVENT_ID = ?";
            PreparedStatement preparedStatement = con1.prepareStatement(updateQuery);
            preparedStatement.setString(1, venue_id);
            preparedStatement.setString(2, ven_name);
            preparedStatement.setInt(3, event_id);
                     
            
            int rowsAffected = preparedStatement.executeUpdate();
            con1.close();
            if (rowsAffected > 0) 
            {
                System.out.println("Update successful");
            } 
            else 
            {
                System.out.println("Update failed");
            }
            
            
                
            
            
            
            
            try ( //TO DISPLAY FINAL TABLE!
                    Connection con4 = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406")) {
                Statement st4 = con4.createStatement();
                String query4 = "SELECT * FROM scheduled_events where event_id="+event_id;
                ResultSet rs4 = st4.executeQuery(query4);
                DefaultTableModel model1 = new DefaultTableModel();
                java.sql.ResultSetMetaData rsmd4 = rs4.getMetaData();
                int cols4 = rsmd4.getColumnCount();
                for (int i = 1; i <= cols4; i++) {
                    model1.addColumn(rsmd4.getColumnName(i));
                }
                while (rs4.next()) 
                {
                    Object[] row = new Object[cols4];
                    for (int i = 1; i <= cols4; i++)
                    {
                        row[i - 1] = rs4.getObject(i);
                    }
                    model1.addRow(row);
                }
                table2.setModel(model1);
                
               
            } catch (SQLException ex) {
                Logger.getLogger(view_table.class.getName()).log(Level.SEVERE, null, ex);
            }
            
            try 
            {
            // TODO add your handling code here:
            
            Class.forName("com.mysql.cj.jdbc.Driver");
            int rowsAffected1;
            try (Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406")) {
                String updateQuery1 = "UPDATE VENUES SET AVAILABILITY = ? WHERE VENUE_ID = ?";
                PreparedStatement preparedStatement1 = con2.prepareStatement(updateQuery1);
                preparedStatement1.setString(1, "Not Available");
                preparedStatement1.setInt(2, fin_venid);
                rowsAffected1 = preparedStatement1.executeUpdate();
            }
            if (rowsAffected1 > 0) 
            {
                //JOptionPane.showMessageDialog(this, "Deleted Successfully!");
                System.out.println("Updated Successfully!");
            } 
            else 
            {
                //JOptionPane.showMessageDialog(this, "Cannot Delete!");
                System.out.println("Cannot Update!");
            }
            }
            catch (SQLException ex) {
                Logger.getLogger(view_table.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(view_table.class.getName()).log(Level.SEVERE, null, ex);
        }
      
    }//GEN-LAST:event_jButton2ActionPerformed

    private void jButton3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton3ActionPerformed
        // TODO add your handling code here:
        Additional_facilities.main(new String[] {});
    }//GEN-LAST:event_jButton3ActionPerformed

    
    public static void main(String args[]) throws ClassNotFoundException {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(view_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(view_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(view_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(view_table.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
        
        
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new view_table().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JTextField name_field2;
    private javax.swing.JTable tab;
    private javax.swing.JTable table2;
    private javax.swing.JTextField ven_field;
    // End of variables declaration//GEN-END:variables
}
