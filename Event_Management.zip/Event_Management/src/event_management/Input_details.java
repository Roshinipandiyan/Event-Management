/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package event_management;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JOptionPane;
import java.time.LocalDate;
import java.time.*;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author ragul
 */

public class Input_details extends javax.swing.JFrame {

    /**
     * Creates new form Input_details
     */
    public Input_details() {
        initComponents();
    }

    /*public void from_time()
    {
        DateTimeFormatter times = DateTimeFormatter.ofPattern("hh:mm a");
        String f_time = f_timefield.getText();
        f_time.setText(times.format());
    }*/
        
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jLabel1 = new javax.swing.JLabel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        eve_typefield = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jButton1 = new javax.swing.JButton();
        f_timefield = new javax.swing.JTextField();
        t_timefield = new javax.swing.JTextField();
        loc_field = new javax.swing.JTextField();
        n_partfield = new javax.swing.JTextField();
        f_datefield = new com.toedter.calendar.JDateChooser();
        t_datefield = new com.toedter.calendar.JDateChooser();
        jLabel9 = new javax.swing.JLabel();
        bud_field = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel1.setFont(new java.awt.Font("Footlight MT Light", 1, 36)); // NOI18N
        jLabel1.setText("EVENT DETAILS");
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(240, 20, -1, -1));

        jLabel2.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel2.setForeground(new java.awt.Color(255, 255, 255));
        jLabel2.setText("EVENT TYPE");
        getContentPane().add(jLabel2, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 115, -1, -1));

        jLabel3.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("FROM DATE");
        getContentPane().add(jLabel3, new org.netbeans.lib.awtextra.AbsoluteConstraints(184, 197, -1, -1));

        jLabel4.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel4.setForeground(new java.awt.Color(255, 255, 255));
        jLabel4.setText("TO DATE");
        getContentPane().add(jLabel4, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 338, -1, -1));

        jLabel5.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("FROM TIME");
        getContentPane().add(jLabel5, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 258, -1, -1));

        jLabel6.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel6.setForeground(new java.awt.Color(255, 255, 255));
        jLabel6.setText("TO TIME");
        getContentPane().add(jLabel6, new org.netbeans.lib.awtextra.AbsoluteConstraints(180, 420, -1, -1));

        jLabel7.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("NO.OF PARTICIPANTS");
        getContentPane().add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 483, -1, -1));

        eve_typefield.setFont(new java.awt.Font("Arial", 0, 14)); // NOI18N
        eve_typefield.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "", "Marriage", "Birthday Party", "Baby Shower", "Reunion/Farewell" }));
        eve_typefield.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                eve_typefieldActionPerformed(evt);
            }
        });
        getContentPane().add(eve_typefield, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 104, 200, 35));

        jLabel8.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("LOCATION");
        getContentPane().add(jLabel8, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 558, -1, -1));

        jButton1.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jButton1.setText("SUBMIT");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(293, 694, -1, -1));

        f_timefield.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        f_timefield.setPreferredSize(new java.awt.Dimension(200, 35));
        getContentPane().add(f_timefield, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 248, -1, -1));

        t_timefield.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        getContentPane().add(t_timefield, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 410, 200, 35));

        loc_field.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        getContentPane().add(loc_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 540, 200, 35));

        n_partfield.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        getContentPane().add(n_partfield, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 473, 200, 35));

        f_datefield.setDateFormatString("dd-MM-yyyy");
        getContentPane().add(f_datefield, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 179, 200, 35));

        t_datefield.setDateFormatString("dd-MM-yyyy");
        getContentPane().add(t_datefield, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 329, 200, 35));

        jLabel9.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel9.setForeground(new java.awt.Color(255, 255, 255));
        jLabel9.setText("BUDGET");
        getContentPane().add(jLabel9, new org.netbeans.lib.awtextra.AbsoluteConstraints(182, 616, -1, -1));

        bud_field.setFont(new java.awt.Font("Arial", 0, 12)); // NOI18N
        getContentPane().add(bud_field, new org.netbeans.lib.awtextra.AbsoluteConstraints(389, 606, 200, 35));

        jLabel10.setFont(new java.awt.Font("Cambria Math", 1, 18)); // NOI18N
        jLabel10.setForeground(new java.awt.Color(255, 255, 255));
        jLabel10.setIcon(new javax.swing.ImageIcon(getClass().getResource("/img9.jpg"))); // NOI18N
        jLabel10.setPreferredSize(new java.awt.Dimension(750, 750));
        getContentPane().add(jLabel10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 750, 750));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private static int privateVariable;
    private static String pv;
    public void setPrivateVariable(int value) 
    {
        privateVariable = value;
    }
    public int getPrivateVariable() 
    {
        return privateVariable;
    }
    
    public void setpv(String val)
    {
        pv = val;
    }
    public String getpv()
    {
        return pv;
    }
    
    
    
    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed
        Input_details privateObject = new Input_details();
        DateTimeFormatter dates = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        
        String eve_type = eve_typefield.getSelectedItem().toString();
        Date f_date = f_datefield.getDate();    
        String f_time = f_timefield.getText();
        Date t_date = t_datefield.getDate();    
        String t_time = t_timefield.getText();
        String n_part = n_partfield.getText();
        int ncon_part = Integer.parseInt(n_part);
        String loc = loc_field.getText();
        String bud = bud_field.getText();
        int bud_con = Integer.parseInt(bud);
        String fin_fdate=null;
        String fin_tdate=null;
        Instant currentInstant = Instant.now();
        LocalDate currentDate = currentInstant.atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localDate1 = f_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        LocalDate localDate2 = t_date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate();
        try
        {
            if (localDate1.isAfter(currentDate) && localDate2.isAfter(currentDate))
            {
                fin_fdate = dates.format(localDate1);
                fin_tdate = dates.format(localDate2);
                
            }
        }
        catch(Exception ex)
        {
            JOptionPane.showMessageDialog(null,ex.getMessage());
        }
        
        
        SimpleDateFormat inputFormat = new SimpleDateFormat("hh:mm a"); // Change to match the user's input format
        SimpleDateFormat outputFormat = new SimpleDateFormat("HH:mm:ss");
        int eventid=0;
        
        try
        {
            
      
            Class.forName("com.mysql.cj.jdbc.Driver");
            Date parsedTime1 = inputFormat.parse(f_time);
            String formattedTime1 = outputFormat.format(parsedTime1);
            Date parsedTime2 = inputFormat.parse(t_time);
            String formattedTime2 = outputFormat.format(parsedTime2);
            
            // Create a local variable 'con'
            try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406");
            PreparedStatement preparedStatement = con.prepareStatement("INSERT INTO events(event_type,from_date,to_date,from_time,to_time,budget,participants_no,location) VALUES (?,?,?,?,?,?,?,?)",Statement.RETURN_GENERATED_KEYS)) 
            
            {

                // Set parameters
                preparedStatement.setString(1, eve_type);
                preparedStatement.setString(2, fin_fdate);
                preparedStatement.setString(3, fin_tdate);
                preparedStatement.setString(4, formattedTime1);
                preparedStatement.setString(5, formattedTime2);
                preparedStatement.setInt(6, bud_con);
                preparedStatement.setInt(7, ncon_part);
                preparedStatement.setString(8, loc);
                
           

                // Execute the statement
                int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) 
                {
                    ResultSet generatedKeys = preparedStatement.getGeneratedKeys();
                    if(generatedKeys.next())
                    {
                        eventid = generatedKeys.getInt(1);
                        privateObject.setPrivateVariable(eventid);
                        privateObject.setpv(loc);
                        System.out.println(eventid);
                        JOptionPane.showMessageDialog(this, "Event details Successfully entered!");
                        dispose();
                        view_table.main(new String[] {});
                        System.out.println("event details inserted successfully!");
                    }
                    else
                    {
                        System.out.println("Failed to retrieve auto-generated key");
                    }
                    
                } 
                else 
                {
                    System.out.println("Failed to insert event details");
                }
            
            }
            
            try(Connection con2 = DriverManager.getConnection("jdbc:mysql://localhost:3306/eventmng", "root", "Ragul@2406");
            PreparedStatement ps = con2.prepareStatement("INSERT INTO scheduled_events(event_id,event_type,from_date,to_date,location) VALUES (?,?,?,?,?)"))
            {
                ps.setInt(1, eventid);
                ps.setString(2, eve_type);
                ps.setString(3, fin_fdate);
                ps.setString(4, fin_tdate);
                ps.setString(5, loc);  
                
                int rowsAffected2 = ps.executeUpdate();
                
                if (rowsAffected2 > 0) 
                {
                    
                    System.out.println("event details inserted successfully!");
                    dispose();
                } 
                else 
                {
                    System.out.println("Failed to insert event details");
                }
            }
            

        } 
        catch (ClassNotFoundException | SQLException ex) 
        {
            try {
                JOptionPane.showMessageDialog(null,ex.getMessage());
                Logger.getLogger(Owner_input.class.getName()).log(Level.SEVERE, null, ex);
                view_table.main(new String[] {});
            } catch (ClassNotFoundException ex1) {
                Logger.getLogger(Input_details.class.getName()).log(Level.SEVERE, null, ex1);
            }
        } catch (ParseException ex) {
            Logger.getLogger(Input_details.class.getName()).log(Level.SEVERE, null, ex);
        } 
        
    }//GEN-LAST:event_jButton1ActionPerformed

    private void eve_typefieldActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_eve_typefieldActionPerformed
        // TODO add your handling code here:
        
    }//GEN-LAST:event_eve_typefieldActionPerformed
    
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Input_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Input_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Input_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Input_details.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        
        
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Input_details().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField bud_field;
    private javax.swing.JComboBox<String> eve_typefield;
    private com.toedter.calendar.JDateChooser f_datefield;
    private javax.swing.JTextField f_timefield;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JTextField loc_field;
    private javax.swing.JTextField n_partfield;
    private com.toedter.calendar.JDateChooser t_datefield;
    private javax.swing.JTextField t_timefield;
    // End of variables declaration//GEN-END:variables
}
